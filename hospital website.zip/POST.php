hi <?php echo $_POST["name"]; ?> <br>
your mail id is: <?php echo $_POST["email"]; ?>