<?php
	echo"Hello Vikas Thakur";
?>
<html>
<head>
<title> new </title>
</head>
<body>
<h1>Vikas Thakur</h1>
</body>
</html>