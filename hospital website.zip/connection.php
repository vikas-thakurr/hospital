<?php
$db = mysqli_connect("localhost:4306", "root","", "joining") or die("unable to connect");
echo"connection successful";
?>
